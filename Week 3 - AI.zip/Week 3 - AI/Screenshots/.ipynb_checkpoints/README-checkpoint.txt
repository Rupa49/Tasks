

Week3_ML.ipynb
  - Task 2: head(), shape, dtypes, missing values (before and after), X and y
  - Task 3: train/test split shapes, before and after scaling
  - Task 4: predictions table, accuracy, confusion matrix

Mini_Project
  - cleaning output, accuracy, the 3 new-student predictions, feature chart
