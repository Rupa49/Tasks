# Student Performance Prediction: Pass or Fail
# Mini Project, Week 3 (Machine Learning)

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

# 1. Load and clean the data
df = pd.read_csv("Dataset.csv")
features = ["Study_Hours", "Attendance", "Previous_Marks", "Assignment_Score"]
df = df.drop_duplicates()
for col in features:
    df[col] = df[col].fillna(df[col].mean())

# 2. Features (X) and target (y)
X = df[features]
y = df["Result"].map({"Pass": 1, "Fail": 0})

# 3. Split and scale
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s = scaler.transform(X_test)

# 4. Train the model
model = LogisticRegression()
model.fit(X_train_s, y_train)

# 5. Accuracy
accuracy = accuracy_score(y_test, model.predict(X_test_s))
print(f"Model accuracy: {accuracy * 100:.1f}%\n")

# 6. Predict for a new student typed by the user
print("Enter details of a new student:")
study = float(input("Study hours per day: "))
attendance = float(input("Attendance %: "))
previous = float(input("Previous marks: "))
assignment = float(input("Assignment score: "))

new_student = pd.DataFrame([[study, attendance, previous, assignment]], columns=features)
prediction = model.predict(scaler.transform(new_student))[0]
probability = model.predict_proba(scaler.transform(new_student))[0][1]

print("\nPrediction:", "PASS" if prediction == 1 else "FAIL")
print(f"Pass probability: {probability:.0%}")
