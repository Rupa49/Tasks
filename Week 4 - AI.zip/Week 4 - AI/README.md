# Week 4: Machine Learning Algorithms & Model Evaluation

In Week 4 I moved from ML concepts to building and comparing real models: two kinds of classification problems, a regression model, evaluation with proper metrics, and a mini project that compares three models.

**Tools:** Python, Jupyter Notebook, Pandas, NumPy, Matplotlib, Scikit-learn

---

## Project Structure

```
Week 4 - AI
├── Project_Report.pdf                 Mini project report + results summary
├── Task1_ML_Algorithms_Report.pdf     Report on 4 ML algorithms
├── Week4_ML_Project.ipynb             Tasks 2, 3, 4 and 5 (code + outputs)
├── Dataset.csv                        Breast Cancer Wisconsin (classification)
├── Student_Marks.csv                  Student marks (regression)
├── Student_Performance.csv            Pass/Fail data (mini project)
├── charts/                            Saved graphs
├── Screenshots/                       Output screenshots
└── README.md
```

## Datasets

| File | Used for | Source |
|------|----------|--------|
| `Dataset.csv` | Task 2 classification | Breast Cancer Wisconsin (Diagnostic), UCI Machine Learning Repository (Wolberg, Street and Mangasarian), loaded via scikit-learn. 569 patients, 30 features |
| `Student_Marks.csv` | Task 3 regression | Practice dataset created for learning (not real student data), 200 students |
| `Student_Performance.csv` | Task 5 mini project | Practice dataset created for learning (not real student data), 400 students |

## What I Built

| Task | Work done |
|------|-----------|
| 1. Algorithms | Report on Logistic Regression, Decision Tree, KNN and Linear Regression (what, how, uses, advantages, limitations) |
| 2. Classification | Logistic Regression, Decision Tree and KNN on breast cancer data |
| 3. Regression | Linear Regression predicting final marks, with actual vs predicted graphs |
| 4. Evaluation | Accuracy, precision, recall, confusion matrices, MAE, MSE, RMSE, R2 and a comparison table |
| 5. Mini project | Student Pass/Fail prediction comparing three models |

## Results

**Classification: breast cancer (114 test patients, positive class = Malignant)**

| Model | Accuracy | Precision | Recall | Missed cancers |
|-------|----------|-----------|--------|----------------|
| Logistic Regression | **96.49%** | 97.50% | 92.86% | 3 |
| KNN | 95.61% | 97.44% | 90.48% | 4 |
| Decision Tree | 91.23% | 94.44% | 80.95% | 8 |

Logistic Regression was the best. For cancer detection, recall is especially important because missing a real cancer is worse than a false alarm.

**Regression: Linear Regression on student marks (40 test students)**

| MAE | MSE | RMSE | R2 |
|-----|-----|------|----|
| 3.40 | 16.63 | 4.08 | 0.905 |

The model explains about 90% of the variation in final marks, and a typical prediction is off by about 4 marks.

**Mini project: Student Pass/Fail (80 test students)**

| Model | Accuracy | Precision | Recall |
|-------|----------|-----------|--------|
| Logistic Regression | **88.75%** | 90.91% | 92.59% |
| Decision Tree | 87.50% | 90.74% | 90.74% |
| KNN | 85.00% | 88.89% | 88.89% |

## How to Run

```bash
pip install numpy pandas matplotlib scikit-learn jupyter
jupyter notebook
```

Open `Week4_ML_Project.ipynb`, keep the three CSV files in the same folder, and choose **Kernel, then Restart & Run All**.

## Limitations

- Results come from a single train/test split, and the test sets are small, so the numbers can change with a different split. Cross-validation would give a more reliable estimate.
- The two student datasets are practice data, so they demonstrate the method and not real student behaviour.
- The cancer model is for learning only and must never replace a doctor.

## What I Learned

- How Logistic Regression, Decision Trees, KNN and Linear Regression work, and when to use each
- Why accuracy alone is not enough, and what precision, recall and the confusion matrix show
- How to judge a regression model with MAE, MSE, RMSE and R2
- Why features are scaled for some models, and why the scaler is fitted on training data only
- How to compare several models fairly on the same data split
